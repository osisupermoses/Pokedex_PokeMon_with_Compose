package com.osisupermoses.pokdexapp.data.remote.dto

data class GenerationViii(
    val icons: IconsX
)