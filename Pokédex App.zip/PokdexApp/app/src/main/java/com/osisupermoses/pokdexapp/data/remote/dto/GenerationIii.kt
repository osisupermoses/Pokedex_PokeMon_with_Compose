package com.osisupermoses.pokdexapp.data.remote.dto

data class GenerationIii(
    val emerald: Emerald,
    val firered-leafgreen: FireredLeafgreen,
    val ruby-sapphire: RubySapphire
)