package com.osisupermoses.pokdexapp.data.remote.dto

data class IconsX(
    val front_default: String,
    val front_female: Any
)