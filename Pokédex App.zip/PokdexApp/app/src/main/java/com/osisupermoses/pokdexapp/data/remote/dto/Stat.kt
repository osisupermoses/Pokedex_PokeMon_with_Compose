package com.osisupermoses.pokdexapp.data.remote.dto

data class Stat(
    val base_stat: Int,
    val effort: Int,
    val stat: StatX
)