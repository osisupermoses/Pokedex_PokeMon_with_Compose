package com.osisupermoses.pokdexapp.data.remote.dto

data class StatX(
    val name: String,
    val url: String
)