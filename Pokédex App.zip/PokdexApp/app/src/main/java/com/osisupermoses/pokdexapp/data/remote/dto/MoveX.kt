package com.osisupermoses.pokdexapp.data.remote.dto

data class MoveX(
    val name: String,
    val url: String
)