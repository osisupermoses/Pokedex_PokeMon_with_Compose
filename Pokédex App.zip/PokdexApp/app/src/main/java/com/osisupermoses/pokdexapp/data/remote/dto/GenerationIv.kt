package com.osisupermoses.pokdexapp.data.remote.dto

data class GenerationIv(
    val diamond-pearl: DiamondPearl,
    val heartgold-soulsilver: HeartgoldSoulsilver,
    val platinum: Platinum
)