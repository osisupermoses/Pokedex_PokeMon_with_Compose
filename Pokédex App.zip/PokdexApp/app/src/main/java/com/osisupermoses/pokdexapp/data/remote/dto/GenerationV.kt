package com.osisupermoses.pokdexapp.data.remote.dto

data class GenerationV(
    val black-white: BlackWhite
)