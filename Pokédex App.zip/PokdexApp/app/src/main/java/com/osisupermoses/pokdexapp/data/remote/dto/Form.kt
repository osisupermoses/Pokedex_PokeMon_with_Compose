package com.osisupermoses.pokdexapp.data.remote.dto

data class Form(
    val name: String,
    val url: String
)