package com.osisupermoses.pokdexapp.data.remote.dto

data class Species(
    val name: String,
    val url: String
)