package com.osisupermoses.pokdexapp.data.remote.dto

data class OfficialArtwork(
    val front_default: String
)