package com.osisupermoses.pokdexapp.data.remote.dto

data class Version(
    val name: String,
    val url: String
)