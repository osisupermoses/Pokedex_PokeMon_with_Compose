package com.osisupermoses.pokdexapp.data.remote.dto

data class GameIndice(
    val game_index: Int,
    val version: Version
)