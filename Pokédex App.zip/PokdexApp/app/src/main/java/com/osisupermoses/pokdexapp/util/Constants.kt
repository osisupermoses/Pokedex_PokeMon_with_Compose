package com.osisupermoses.pokdexapp.util

object Constants {

    const val BASE_URL = "https://pokeapi.co/api/v2/"
}