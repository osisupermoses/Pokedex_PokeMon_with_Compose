package com.osisupermoses.pokdexapp.data.remote.dto

data class Versions(
    val generation-i: GenerationI,
    val generation-ii: GenerationIi,
    val generation-iii: GenerationIii,
    val generation-iv: GenerationIv,
    val generation-v: GenerationV,
    val generation-vi: GenerationVi,
    val generation-vii: GenerationVii,
    val generation-viii: GenerationViii
)