package com.osisupermoses.pokdexapp.data.remote.dto

data class GenerationVii(
    val icons: Icons,
    val ultra-sun-ultra-moon: UltraSunUltraMoon
)