package com.osisupermoses.pokdexapp.data.remote.dto

data class Result(
    val name: String,
    val url: String
)