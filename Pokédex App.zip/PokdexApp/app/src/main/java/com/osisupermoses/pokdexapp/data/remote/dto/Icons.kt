package com.osisupermoses.pokdexapp.data.remote.dto

data class Icons(
    val front_default: String,
    val front_female: Any
)