package com.osisupermoses.pokdexapp.data.remote.dto

data class GenerationIi(
    val crystal: Crystal,
    val gold: Gold,
    val silver: Silver
)