package com.osisupermoses.pokdexapp.data.remote.dto

data class GenerationI(
    val red-blue: RedBlue,
    val yellow: Yellow
)