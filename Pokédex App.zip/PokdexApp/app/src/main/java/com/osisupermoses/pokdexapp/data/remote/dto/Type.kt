package com.osisupermoses.pokdexapp.data.remote.dto

data class Type(
    val slot: Int,
    val type: TypeX
)