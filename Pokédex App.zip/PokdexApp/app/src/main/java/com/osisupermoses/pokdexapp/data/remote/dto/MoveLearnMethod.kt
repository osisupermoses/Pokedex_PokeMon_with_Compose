package com.osisupermoses.pokdexapp.data.remote.dto

data class MoveLearnMethod(
    val name: String,
    val url: String
)