package com.osisupermoses.pokdexapp.data.remote.dto

data class GenerationVi(
    val omegaruby-alphasapphire: OmegarubyAlphasapphire,
    val x-y: XY
)